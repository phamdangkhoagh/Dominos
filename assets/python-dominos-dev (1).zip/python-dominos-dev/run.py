import pygame
from menu import Menu
if __name__ == '__main__':
    pygame.init()
    pygame.mixer.init()
    Menu().run()